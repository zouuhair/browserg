import React from 'react';
import { motion } from 'framer-motion';
import { GameCard } from './GameCard';
import { Game } from '../types/Game';

interface GameGridProps {
  games: Game[];
  onPlayGame: (game: Game) => void;
  onToggleFavorite: (gameId: number) => void;
  isFavorite: (gameId: number) => boolean;
}

export const GameGrid: React.FC<GameGridProps> = ({
  games,
  onPlayGame,
  onToggleFavorite,
  isFavorite
}) => {
  if (games.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-16"
      >
        <div className="text-6xl mb-4">🎮</div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">No games found</h3>
        <p className="text-gray-600">Try adjusting your search or category filters</p>
      </motion.div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
      {games.map((game, index) => (
        <GameCard
          key={game.id}
          game={game}
          onPlay={onPlayGame}
          onToggleFavorite={onToggleFavorite}
          isFavorite={isFavorite(game.id)}
          index={index}
        />
      ))}
    </div>
  );
};