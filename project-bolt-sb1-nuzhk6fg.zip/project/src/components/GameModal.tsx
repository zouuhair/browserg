import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Loader } from 'lucide-react';
import { Game } from '../types/Game';

interface GameModalProps {
  game: Game | null;
  isOpen: boolean;
  onClose: () => void;
}

export const GameModal: React.FC<GameModalProps> = ({ game, isOpen, onClose }) => {
  const [isLoading, setIsLoading] = React.useState(true);

  useEffect(() => {
    if (isOpen && game) {
      setIsLoading(true);
      document.body.style.overflow = 'hidden';
      
      // Simulate loading time
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 1500);

      return () => {
        clearTimeout(timer);
        document.body.style.overflow = 'auto';
      };
    } else {
      document.body.style.overflow = 'auto';
    }
  }, [isOpen, game]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      return () => document.removeEventListener('keydown', handleEscape);
    }
  }, [isOpen, onClose]);

  if (!game) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl h-[80vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6 flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <span className="text-4xl">{game.icon}</span>
                <div>
                  <h2 className="text-2xl font-bold">{game.title}</h2>
                  <p className="text-purple-100">{game.description}</p>
                </div>
              </div>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClose}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
              >
                <X className="w-6 h-6" />
              </motion.button>
            </div>

            {/* Game Content */}
            <div className="h-full bg-gray-50 flex items-center justify-center">
              {isLoading ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center"
                >
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="inline-block mb-4"
                  >
                    <Loader className="w-12 h-12 text-purple-600" />
                  </motion.div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">Loading {game.title}...</h3>
                  <p className="text-gray-600">Please wait while we prepare your game</p>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="w-full h-full"
                >
                  {game.url ? (
                    <iframe
                      src={game.url}
                      className="w-full h-full border-none"
                      allow="fullscreen; autoplay; encrypted-media"
                      allowFullScreen
                      title={game.title}
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center p-8">
                      <div className="text-8xl mb-6">{game.icon}</div>
                      <h2 className="text-3xl font-bold text-gray-800 mb-4">Now Playing: {game.title}</h2>
                      <p className="text-gray-600 mb-6 max-w-md">{game.description}</p>
                      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-8 py-4 rounded-xl text-xl font-semibold">
                        🎮 Game is running! 🎮
                      </div>
                      <p className="text-gray-500 mt-4 text-sm">
                        Use arrow keys to move, spacebar to interact
                      </p>
                      <p className="text-gray-400 mt-2 text-xs">
                        This is a demo. In a real implementation, the actual game would load here.
                      </p>
                    </div>
                  )}
                </motion.div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};