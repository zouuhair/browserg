import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Heart, Clock, TrendingUp } from 'lucide-react';

interface StatsPanelProps {
  totalGames: number;
  playCount: number;
  favoriteCount: number;
  recentlyPlayedCount: number;
}

export const StatsPanel: React.FC<StatsPanelProps> = ({
  totalGames,
  playCount,
  favoriteCount,
  recentlyPlayedCount
}) => {
  const stats = [
    {
      icon: Trophy,
      label: 'Total Games',
      value: totalGames,
      color: 'from-yellow-500 to-orange-500'
    },
    {
      icon: TrendingUp,
      label: 'Games Played',
      value: playCount,
      color: 'from-green-500 to-teal-500'
    },
    {
      icon: Heart,
      label: 'Favorites',
      value: favoriteCount,
      color: 'from-red-500 to-pink-500'
    },
    {
      icon: Clock,
      label: 'Recently Played',
      value: recentlyPlayedCount,
      color: 'from-blue-500 to-purple-500'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-white rounded-xl p-4 shadow-lg"
        >
          <div className="flex items-center space-x-3">
            <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-lg flex items-center justify-center`}>
              <stat.icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};