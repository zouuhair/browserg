import React from 'react';
import { motion } from 'framer-motion';
import { Star, Play, Heart } from 'lucide-react';
import { Game } from '../types/Game';

interface GameCardProps {
  game: Game;
  onPlay: (game: Game) => void;
  onToggleFavorite: (gameId: number) => void;
  isFavorite: boolean;
  index: number;
}

export const GameCard: React.FC<GameCardProps> = ({
  game,
  onPlay,
  onToggleFavorite,
  isFavorite,
  index
}) => {
  const gradients = [
    'from-purple-500 to-pink-500',
    'from-blue-500 to-cyan-500',
    'from-green-500 to-teal-500',
    'from-yellow-500 to-orange-500',
    'from-red-500 to-pink-500',
    'from-indigo-500 to-purple-500',
    'from-cyan-500 to-blue-500',
    'from-teal-500 to-green-500',
    'from-orange-500 to-red-500',
    'from-pink-500 to-rose-500'
  ];

  const gradient = gradients[index % gradients.length];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ y: -8, scale: 1.02 }}
      className="group relative"
    >
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden transition-all duration-300 group-hover:shadow-2xl">
        {/* Game Icon */}
        <div className={`h-32 bg-gradient-to-br ${gradient} flex items-center justify-center relative overflow-hidden`}>
          <motion.div
            whileHover={{ scale: 1.1, rotate: 5 }}
            className="text-6xl filter drop-shadow-lg"
          >
            {game.icon}
          </motion.div>
          
          {/* Favorite Button */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(game.id);
            }}
            className="absolute top-3 right-3 p-2 bg-white/20 backdrop-blur-sm rounded-full transition-all duration-200 hover:bg-white/30"
          >
            <Heart
              className={`w-5 h-5 transition-colors ${
                isFavorite ? 'text-red-500 fill-current' : 'text-white'
              }`}
            />
          </motion.button>

          {/* Play Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            whileHover={{ opacity: 1 }}
            className="absolute inset-0 bg-black/20 flex items-center justify-center"
          >
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => onPlay(game)}
              className="bg-white/90 backdrop-blur-sm rounded-full p-3 shadow-lg"
            >
              <Play className="w-6 h-6 text-gray-800 ml-1" />
            </motion.button>
          </motion.div>
        </div>

        {/* Game Info */}
        <div className="p-4">
          <h3 className="font-bold text-lg text-gray-800 mb-2 line-clamp-1">
            {game.title}
          </h3>
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">
            {game.description}
          </p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span className="text-sm font-semibold text-gray-700">
                {game.rating}
              </span>
            </div>
            <span className="text-sm text-gray-500">
              {game.plays} plays
            </span>
          </div>

          {/* Category Badge */}
          <div className="mt-3">
            <span className="inline-block px-3 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full capitalize">
              {game.category}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};