export interface Game {
  id: number;
  title: string;
  description: string;
  category: string;
  rating: number;
  plays: string;
  icon: string;
  url?: string;
}

export type Category = 'all' | 'action' | 'puzzle' | 'racing' | 'strategy' | 'arcade';