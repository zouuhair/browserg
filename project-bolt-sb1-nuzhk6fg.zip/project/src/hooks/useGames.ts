import { useState, useMemo } from 'react';
import { Game, Category } from '../types/Game';
import { games } from '../data/games';

export const useGames = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category>('all');
  const [sortBy, setSortBy] = useState<'rating' | 'plays' | 'title'>('rating');

  const filteredGames = useMemo(() => {
    let filtered = games.filter(game => {
      const matchesCategory = selectedCategory === 'all' || game.category === selectedCategory;
      const matchesSearch = 
        game.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        game.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      return matchesCategory && matchesSearch;
    });

    // Sort games
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'rating':
          return b.rating - a.rating;
        case 'plays':
          return parseFloat(b.plays.replace(/[^\d.]/g, '')) - parseFloat(a.plays.replace(/[^\d.]/g, ''));
        case 'title':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });

    return filtered;
  }, [searchTerm, selectedCategory, sortBy]);

  return {
    games: filteredGames,
    searchTerm,
    setSearchTerm,
    selectedCategory,
    setSelectedCategory,
    sortBy,
    setSortBy
  };
};