import { useLocalStorage } from './useLocalStorage';

interface GameStats {
  playCount: number;
  lastPlayed: string;
  favorites: number[];
  recentlyPlayed: number[];
}

export const useGameStats = () => {
  const [stats, setStats] = useLocalStorage<GameStats>('gameStats', {
    playCount: 0,
    lastPlayed: '',
    favorites: [],
    recentlyPlayed: []
  });

  const incrementPlayCount = (gameId: number) => {
    setStats(prev => ({
      ...prev,
      playCount: prev.playCount + 1,
      lastPlayed: new Date().toISOString(),
      recentlyPlayed: [gameId, ...prev.recentlyPlayed.filter(id => id !== gameId)].slice(0, 10)
    }));
  };

  const toggleFavorite = (gameId: number) => {
    setStats(prev => ({
      ...prev,
      favorites: prev.favorites.includes(gameId)
        ? prev.favorites.filter(id => id !== gameId)
        : [...prev.favorites, gameId]
    }));
  };

  const isFavorite = (gameId: number) => stats.favorites.includes(gameId);

  return {
    stats,
    incrementPlayCount,
    toggleFavorite,
    isFavorite
  };
};